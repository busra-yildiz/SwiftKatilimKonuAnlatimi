import UIKit

class Ev {
    var pencereSayisi:Int?
    
    init(pencereSayisi:Int){
        self.pencereSayisi = pencereSayisi
    }

}


class Saray:Ev {
    var kuleSayisi:Int?
    //normalde    init(kuleSayisi:Int){ olarak tanımlama yapmıştık. Fakat biz gelip burada bir de super.init nokta diyerek ev classı içinden pencere sayısını almak istediğimiz için bunun yanına bir de superclass içine eklediğimiz pencereSayisi kısmını ekledik. Biz bunu ınt demek yerine direk sayı da girebilirdik. Fakat biz nesne tabanlı programlamada daha geniş kapsamlı düşünmeyi öncelik haline getirdiğimiz için dışarıdan kullanıcıdan gelmesini daha ön görüyoruz. Bu yüzden bu şekilde yaptık.
    init(kuleSayisi:Int, pencereSayisi:Int){
        self.kuleSayisi = kuleSayisi
        super.init(pencereSayisi: pencereSayisi)
    }
    
}

class Villa:Ev {
    var garajVarMi:Bool?
    //normalde    init(garajVarMi:Bool){ olarak tanımlama yapmıştık. Fakat biz gelip burada bir de super.init nokta diyerek ev classı içinden pencere sayısını almak istediğimiz için bunun yanına bir de superclass içine eklediğimiz pencereSayisi kısmını ekledik. Biz bunu ınt demek yerine direk sayı da girebilirdik. Fakat biz nesne tabanlı programlamada daha geniş kapsamlı düşünmeyi öncelik haline getirdiğimiz için dışarıdan kullanıcıdan gelmesini daha ön görüyoruz. Bu yüzden bu şekilde yaptık.
    init(garajVarMi:Bool, pencereSayisi:Int){
        self.garajVarMi = garajVarMi
        super.init(pencereSayisi: pencereSayisi)

    }
    
}

let topkapiSarayi = Saray(kuleSayisi: 5, pencereSayisi: 300)
let bogazVilla = Villa(garajVarMi: true, pencereSayisi: 30)

print (topkapiSarayi.kuleSayisi!)
print (topkapiSarayi.pencereSayisi!)

print (bogazVilla.garajVarMi!)
print (bogazVilla.pencereSayisi!)
